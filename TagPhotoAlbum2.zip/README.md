# Tag Photo Album

一个基于 Material Design 3 设计的现代化照片管理应用，支持标签、文件夹和位置分类管理。

## 功能特性

- 🎨 **Material Design 3** - 使用官方 Vuetify 组件库
- 🏷️ **智能标签管理** - 按标签分类和筛选照片
- 📁 **文件夹组织** - 按文件夹管理照片
- 📍 **位置信息** - 记录和筛选照片拍摄地点
- 🖼️ **瀑布流展示** - 响应式瀑布流图片布局
- 🔍 **详情查看** - 点击图片查看详情并编辑信息
- 📱 **响应式设计** - 适配各种屏幕尺寸
- 🔄 **REST API** - 完整的后端 API 支持

## 技术栈

### 前端
- Vue 3 + Composition API
- Vuetify 3 (Material Design 3)
- Vue Router
- Pinia (状态管理)
- Axios (HTTP 客户端)

### 后端
- Node.js + Express
- CORS 支持
- RESTful API 设计

## 快速开始

### 安装依赖

```bash
npm install
```

### 开发模式

启动前端开发服务器：
```bash
npm run dev
```

启动后端 API 服务器：
```bash
npm run serve
```

### 构建生产版本

```bash
npm run build
```

## 项目结构

```
tag-photo-album/
├── src/
│   ├── components/          # Vue 组件
│   │   ├── PhotoMasonry.vue # 瀑布流图片展示
│   │   ├── PhotoDetail.vue  # 图片详情弹窗
│   │   └── Sidebar.vue      # 左侧导航栏
│   ├── views/
│   │   └── Home.vue         # 主页面
│   ├── stores/
│   │   └── photoStore.js    # Pinia 状态管理
│   ├── api/
│   │   └── photoApi.js      # API 接口
│   ├── plugins/
│   │   └── vuetify.js       # Vuetify 配置
│   ├── router/
│   │   └── index.js         # 路由配置
│   └── main.js              # 应用入口
├── server/
│   └── index.js             # Express 服务器
├── package.json
├── vite.config.js
└── README.md
```

## 核心功能

### 1. 左侧导航栏
- 支持标签、文件夹、地点三个分类
- 可折叠/展开的侧边栏
- 点击分类项筛选对应照片

### 2. 瀑布流图片展示
- 响应式布局，自动适配屏幕尺寸
- 图片悬停显示基本信息
- 点击图片查看详情

### 3. 图片详情编辑
- 查看完整尺寸图片
- 编辑标题、描述、标签等信息
- 实时保存修改

### 4. 筛选功能
- 按标签筛选
- 按文件夹筛选
- 按地点筛选
- 组合筛选支持

## API 文档

详细的 REST API 文档请参考 [API_DOCUMENTATION.md](./API_DOCUMENTATION.md)

## 开发说明

### 添加新功能
1. 在 `src/stores/photoStore.js` 中添加状态和逻辑
2. 创建对应的 Vue 组件
3. 在 `src/api/photoApi.js` 中添加 API 接口
4. 在 `server/index.js` 中添加后端路由

### 自定义主题
修改 `src/plugins/vuetify.js` 中的主题配置：

```javascript
theme: {
  defaultTheme: 'light',
  themes: {
    light: {
      colors: {
        primary: '#1976d2',
        // 自定义颜色...
      }
    }
  }
}
```

## 部署

### 开发环境
```bash
# 前端开发服务器 (端口 3000)
npm run dev

# 后端 API 服务器 (端口 3001)
npm run serve
```

### 生产环境
```bash
# 构建前端
npm run build

# 启动生产服务器
npm run serve
```

## 许可证

MIT License