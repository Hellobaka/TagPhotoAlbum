<template>
  <v-dialog
    v-model="isOpen"
    max-width="1200"
    persistent
    @click:outside="close"
  >
    <v-card class="photo-detail-card">
      <v-card-text class="pa-0">
        <div class="detail-content">
          <!-- 图片区域 -->
          <div class="image-section">
            <v-img
              :src="photo.url"
              :alt="photo.title"
              cover
              class="detail-image"
            />
          </div>

          <!-- 信息区域 -->
          <div class="info-section">
            <v-card-title class="px-4 pt-4 pb-2">
              <v-text-field
                v-model="editablePhoto.title"
                label="标题"
                variant="outlined"
                density="compact"
              />
            </v-card-title>

            <v-card-text class="px-4 py-2">
              <!-- 描述 -->
              <v-textarea
                v-model="editablePhoto.description"
                label="描述"
                variant="outlined"
                rows="3"
                class="mb-4"
              />

              <!-- 标签 -->
              <div class="mb-4">
                <div class="d-flex align-center mb-2">
                  <h4 class="text-h6">标签</h4>
                  <v-spacer />
                  <v-btn
                    size="small"
                    variant="text"
                    @click="showTagInput = !showTagInput"
                  >
                    <v-icon>mdi-plus</v-icon>
                    添加标签
                  </v-btn>
                </div>

                <div v-if="showTagInput" class="d-flex mb-2">
                  <v-text-field
                    v-model="newTag"
                    placeholder="输入新标签"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="mr-2"
                    @keyup.enter="addTag"
                  />
                  <v-btn
                    color="primary"
                    @click="addTag"
                  >
                    添加
                  </v-btn>
                </div>

                <div class="tags-container">
                  <v-chip
                    v-for="tag in editablePhoto.tags"
                    :key="tag"
                    closable
                    @click:close="removeTag(tag)"
                    class="ma-1"
                  >
                    {{ tag }}
                  </v-chip>
                </div>
              </div>

              <!-- 文件夹和位置 -->
              <v-row>
                <v-col cols="6">
                  <v-select
                    v-model="editablePhoto.folder"
                    :items="folders"
                    label="文件夹"
                    variant="outlined"
                    density="compact"
                  />
                </v-col>
                <v-col cols="6">
                  <v-text-field
                    v-model="editablePhoto.location"
                    label="地点"
                    variant="outlined"
                    density="compact"
                  />
                </v-col>
              </v-row>
            </v-card-text>

            <!-- 操作按钮 -->
            <v-card-actions class="px-4 pb-4">
              <v-spacer />
              <v-btn
                variant="text"
                @click="close"
              >
                取消
              </v-btn>
              <v-btn
                color="primary"
                @click="save"
              >
                保存
              </v-btn>
            </v-card-actions>
          </div>
        </div>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  photo: {
    type: Object,
    required: true
  },
  folders: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['update:modelValue', 'save', 'close'])

const isOpen = computed({
  get: () => props.modelValue,
  set: (value) => emit('update:modelValue', value)
})

const editablePhoto = ref({})
const newTag = ref('')
const showTagInput = ref(false)

watch(() => props.photo, (newPhoto) => {
  editablePhoto.value = { ...newPhoto }
}, { immediate: true })

const addTag = () => {
  if (newTag.value.trim() && !editablePhoto.value.tags.includes(newTag.value.trim())) {
    editablePhoto.value.tags.push(newTag.value.trim())
    newTag.value = ''
    showTagInput.value = false
  }
}

const removeTag = (tag) => {
  editablePhoto.value.tags = editablePhoto.value.tags.filter(t => t !== tag)
}

const save = () => {
  emit('save', editablePhoto.value)
  close()
}

const close = () => {
  isOpen.value = false
  emit('close')
  newTag.value = ''
  showTagInput.value = false
}
</script>

<style scoped>
.photo-detail-card {
  border-radius: 12px;
}

.detail-content {
  display: flex;
  height: 600px;
}

.image-section {
  flex: 1;
  background: #000;
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: 60%;
}

.detail-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.info-section {
  flex: 1;
  max-width: 400px;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.tags-container {
  display: flex;
  flex-wrap: wrap;
}

/* 响应式设计 */
@media (max-width: 960px) {
  .detail-content {
    flex-direction: column;
    height: auto;
    max-height: 80vh;
  }

  .image-section {
    max-width: 100%;
    height: 300px;
  }

  .info-section {
    max-width: 100%;
  }
}
</style>