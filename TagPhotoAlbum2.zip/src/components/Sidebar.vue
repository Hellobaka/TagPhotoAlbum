<template>
  <v-navigation-drawer
    v-model="isOpen"
    :rail="isCollapsed"
    permanent
    class="sidebar"
  >
    <template #prepend>
      <div class="sidebar-header">
        <v-btn
          icon
          variant="text"
          @click="toggleCollapse"
          class="collapse-btn"
        >
          <v-icon>{{ isCollapsed ? 'mdi-chevron-right' : 'mdi-chevron-left' }}</v-icon>
        </v-btn>
      </div>
    </template>

    <v-list density="compact" nav>
      <v-list-item
        v-for="tab in tabs"
        :key="tab.id"
        :value="tab.id"
        :active="activeTab === tab.id"
        @click="setActiveTab(tab.id)"
        class="nav-item"
      >
        <template #prepend>
          <v-icon>{{ tab.icon }}</v-icon>
        </template>

        <v-list-item-title>{{ tab.label }}</v-list-item-title>
      </v-list-item>
    </v-list>

    <!-- 标签列表 -->
    <div v-if="activeTab === 'tags' && !isCollapsed" class="tab-content">
      <v-list density="compact" class="px-2">
        <v-list-item
          v-for="tag in tags"
          :key="tag"
          @click="selectTag(tag)"
          class="tag-item"
        >
          <template #prepend>
            <v-icon size="small">mdi-tag</v-icon>
          </template>
          <v-list-item-title>{{ tag }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </div>

    <!-- 文件夹列表 -->
    <div v-if="activeTab === 'folders' && !isCollapsed" class="tab-content">
      <v-list density="compact" class="px-2">
        <v-list-item
          v-for="folder in folders"
          :key="folder"
          @click="selectFolder(folder)"
          class="folder-item"
        >
          <template #prepend>
            <v-icon size="small">mdi-folder</v-icon>
          </template>
          <v-list-item-title>{{ folder }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </div>

    <!-- 地点列表 -->
    <div v-if="activeTab === 'locations' && !isCollapsed" class="tab-content">
      <v-list density="compact" class="px-2">
        <v-list-item
          v-for="location in locations"
          :key="location"
          @click="selectLocation(location)"
          class="location-item"
        >
          <template #prepend>
            <v-icon size="small">mdi-map-marker</v-icon>
          </template>
          <v-list-item-title>{{ location }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </div>
  </v-navigation-drawer>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true
  },
  activeTab: {
    type: String,
    default: 'tags'
  },
  tags: {
    type: Array,
    default: () => []
  },
  folders: {
    type: Array,
    default: () => []
  },
  locations: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['update:modelValue', 'update:activeTab', 'select-tag', 'select-folder', 'select-location'])

const isOpen = computed({
  get: () => props.modelValue,
  set: (value) => emit('update:modelValue', value)
})

const isCollapsed = ref(false)

const tabs = [
  { id: 'tags', label: '标签', icon: 'mdi-tag' },
  { id: 'folders', label: '文件夹', icon: 'mdi-folder' },
  { id: 'locations', label: '地点', icon: 'mdi-map-marker' }
]

const toggleCollapse = () => {
  isCollapsed.value = !isCollapsed.value
}

const setActiveTab = (tabId) => {
  emit('update:activeTab', tabId)
}

const selectTag = (tag) => {
  emit('select-tag', tag)
}

const selectFolder = (folder) => {
  emit('select-folder', folder)
}

const selectLocation = (location) => {
  emit('select-location', location)
}
</script>

<style scoped>
.sidebar {
  border-right: 1px solid #e0e0e0;
}

.sidebar-header {
  padding: 8px;
  border-bottom: 1px solid #e0e0e0;
}

.collapse-btn {
  margin-left: 8px;
}

.nav-item {
  border-radius: 8px;
  margin: 4px 8px;
}

.tab-content {
  border-top: 1px solid #e0e0e0;
  margin-top: 8px;
  padding-top: 8px;
}

.tag-item,
.folder-item,
.location-item {
  border-radius: 4px;
  margin: 2px 0;
}

.tag-item:hover,
.folder-item:hover,
.location-item:hover {
  background-color: #f5f5f5;
}
</style>