<template>
  <div class="home">
    <div class="layout">
      <!-- 左侧导航栏 -->
      <div class="sidebar" :class="{ 'sidebar-collapsed': isCollapsed }">
        <div class="sidebar-header">
          <button class="collapse-btn" @click="toggleSidebar">
            <span class="material-icons">{{ isCollapsed ? 'chevron_right' : 'chevron_left' }}</span>
          </button>
        </div>

        <nav class="nav-tabs">
          <div
            v-for="tab in tabs"
            :key="tab.id"
            class="nav-tab"
            :class="{ 'active': activeTab === tab.id }"
            @click="setActiveTab(tab.id)"
          >
            <span class="material-icons tab-icon">{{ tab.icon }}</span>
            <span class="tab-label" v-if="!isCollapsed">{{ tab.label }}</span>
          </div>
        </nav>

        <!-- 筛选内容区域 -->
        <div class="filter-content" v-if="!isCollapsed">
          <!-- 标签筛选 -->
          <div v-if="activeTab === 'tags'" class="filter-section">
            <h3 class="filter-title">标签</h3>
            <div class="filter-items">
              <div
                v-for="tag in photoStore.allTags"
                :key="tag"
                class="filter-item"
                :class="{ 'active': selectedTags.includes(tag) }"
                @click="toggleTag(tag)"
              >
                <span class="material-icons">local_offer</span>
                <span>{{ tag }}</span>
              </div>
            </div>
          </div>

          <!-- 文件夹筛选 -->
          <div v-if="activeTab === 'folders'" class="filter-section">
            <h3 class="filter-title">文件夹</h3>
            <div class="filter-items">
              <div
                v-for="folder in photoStore.allFolders"
                :key="folder"
                class="filter-item"
                :class="{ 'active': selectedFolder === folder }"
                @click="selectFolder(folder)"
              >
                <span class="material-icons">folder</span>
                <span>{{ folder }}</span>
              </div>
            </div>
          </div>

          <!-- 地点筛选 -->
          <div v-if="activeTab === 'locations'" class="filter-section">
            <h3 class="filter-title">地点</h3>
            <div class="filter-items">
              <div
                v-for="location in photoStore.allLocations"
                :key="location"
                class="filter-item"
                :class="{ 'active': selectedLocation === location }"
                @click="selectLocation(location)"
              >
                <span class="material-icons">location_on</span>
                <span>{{ location }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 主内容区 -->
      <div class="main-content">
        <div class="content-header">
          <div class="header-content">
            <h1>{{ getActiveTabLabel }}</h1>
            <div class="search-box">
              <div class="search-input-wrapper">
                <span class="material-icons search-icon">search</span>
                <input
                  v-model="searchQuery"
                  type="text"
                  placeholder="搜索图片..."
                  class="search-input"
                />
                <button
                  v-if="searchQuery"
                  class="clear-search"
                  @click="clearSearch"
                >
                  <span class="material-icons">close</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 筛选状态显示 -->
        <div v-if="selectedTags.length > 0 || selectedFolder || selectedLocation || searchQuery" class="filter-status">
          <div class="filter-chips">
            <div v-for="tag in selectedTags" :key="tag" class="filter-chip">
              <span class="material-icons">local_offer</span>
              {{ tag }}
              <span class="remove-chip" @click="toggleTag(tag)">×</span>
            </div>
            <div v-if="selectedFolder" class="filter-chip">
              <span class="material-icons">folder</span>
              {{ selectedFolder }}
              <span class="remove-chip" @click="selectFolder(selectedFolder)">×</span>
            </div>
            <div v-if="selectedLocation" class="filter-chip">
              <span class="material-icons">location_on</span>
              {{ selectedLocation }}
              <span class="remove-chip" @click="selectLocation(selectedLocation)">×</span>
            </div>
            <div v-if="searchQuery" class="filter-chip">
              <span class="material-icons">search</span>
              搜索: "{{ searchQuery }}"
              <span class="remove-chip" @click="clearSearch">×</span>
            </div>
            <button class="clear-all-btn" @click="clearAllFilters">清除全部</button>
          </div>
        </div>

        <!-- 瀑布流图片展示 -->
        <div class="masonry-grid">
          <div
            v-for="photo in filteredPhotos"
            :key="photo.id"
            class="masonry-item"
            @click="openPhotoDetail(photo)"
          >
            <img :src="photo.url" :alt="photo.title" />
          </div>
        </div>
      </div>
    </div>

    <!-- 图片详情Overlay -->
    <div v-if="selectedPhoto" class="overlay" @click="closePhotoDetail">
      <div class="overlay-content" @click.stop>
        <div class="photo-container">
          <img :src="selectedPhoto.url" :alt="selectedPhoto.title" />
        </div>
        <div class="photo-info">
          <div class="info-section">
            <h3>基本信息</h3>
            <div class="info-item">
              <label>标题:</label>
              <input v-model="selectedPhoto.title" />
            </div>
            <div class="info-item">
              <label>描述:</label>
              <textarea v-model="selectedPhoto.description" rows="3"></textarea>
            </div>
          </div>

          <div class="info-section">
            <h3>标签</h3>
            <div class="tags">
              <span
                v-for="tag in selectedPhoto.tags"
                :key="tag"
                class="tag"
              >
                {{ tag }}
                <span class="remove-tag" @click="removeTag(tag)">×</span>
              </span>
              <input
                v-model="newTag"
                placeholder="添加标签..."
                @keyup.enter="addTag"
                class="tag-input"
              />
            </div>
          </div>

          <div class="info-section">
            <h3>位置信息</h3>
            <div class="info-item">
              <label>文件夹:</label>
              <span>{{ selectedPhoto.folder }}</span>
            </div>
            <div class="info-item">
              <label>地点:</label>
              <input v-model="selectedPhoto.location" />
            </div>
          </div>

          <div class="action-buttons">
            <button class="btn btn-primary" @click="savePhotoInfo">保存</button>
            <button class="btn btn-secondary" @click="closePhotoDetail">取消</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { usePhotoStore } from '@/stores/photoStore'

// 响应式数据
const isCollapsed = ref(false)
const activeTab = ref('tags')
const selectedPhoto = ref(null)
const newTag = ref('')
const selectedTags = ref([])
const selectedFolder = ref(null)
const selectedLocation = ref(null)
const searchQuery = ref('')

// 标签页配置
const tabs = [
  { id: 'tags', label: '标签', icon: 'local_offer' },
  { id: 'folders', label: '文件夹', icon: 'folder' },
  { id: 'locations', label: '地点', icon: 'location_on' }
]

// 使用 Pinia store
const photoStore = usePhotoStore()

// 计算属性
const getActiveTabLabel = computed(() => {
  const tab = tabs.find(t => t.id === activeTab.value)
  return tab ? tab.label : ''
})

const filteredPhotos = computed(() => {
  // 根据筛选条件筛选图片
  let photos = photoStore.photos

  // 标签筛选
  if (selectedTags.value.length > 0) {
    photos = photos.filter(photo =>
      selectedTags.value.some(tag => photo.tags.includes(tag))
    )
  }

  // 文件夹筛选
  if (selectedFolder.value) {
    photos = photos.filter(photo => photo.folder === selectedFolder.value)
  }

  // 地点筛选
  if (selectedLocation.value) {
    photos = photos.filter(photo => photo.location === selectedLocation.value)
  }

  // 搜索筛选
  if (searchQuery.value.trim()) {
    const query = searchQuery.value.toLowerCase().trim()
    photos = photos.filter(photo =>
      photo.title.toLowerCase().includes(query) ||
      photo.description.toLowerCase().includes(query) ||
      photo.tags.some(tag => tag.toLowerCase().includes(query)) ||
      photo.folder.toLowerCase().includes(query) ||
      photo.location.toLowerCase().includes(query)
    )
  }

  return photos
})

// 方法
const toggleSidebar = () => {
  isCollapsed.value = !isCollapsed.value
}

const setActiveTab = (tabId) => {
  activeTab.value = tabId
  photoStore.setActiveTab(tabId)
  // 切换标签页时清除筛选
  selectedTags.value = []
  selectedFolder.value = null
  selectedLocation.value = null
}

const toggleTag = (tag) => {
  const index = selectedTags.value.indexOf(tag)
  if (index > -1) {
    selectedTags.value.splice(index, 1)
  } else {
    selectedTags.value.push(tag)
  }
}

const selectFolder = (folder) => {
  selectedFolder.value = selectedFolder.value === folder ? null : folder
}

const selectLocation = (location) => {
  selectedLocation.value = selectedLocation.value === location ? null : location
}

const clearAllFilters = () => {
  selectedTags.value = []
  selectedFolder.value = null
  selectedLocation.value = null
  searchQuery.value = ''
}

const clearSearch = () => {
  searchQuery.value = ''
}

const openPhotoDetail = (photo) => {
  selectedPhoto.value = { ...photo }
}

const closePhotoDetail = () => {
  selectedPhoto.value = null
  newTag.value = ''
}

const addTag = () => {
  if (newTag.value.trim() && !selectedPhoto.value.tags.includes(newTag.value.trim())) {
    selectedPhoto.value.tags.push(newTag.value.trim())
    newTag.value = ''
  }
}

const removeTag = (tag) => {
  selectedPhoto.value.tags = selectedPhoto.value.tags.filter(t => t !== tag)
}

const savePhotoInfo = () => {
  // 在实际应用中，这里应该调用API保存数据
  photoStore.updatePhoto(selectedPhoto.value)
  closePhotoDetail()
}

onMounted(() => {
  // 初始化数据
  photoStore.initializeMockData()
})
</script>

<style scoped>
.home {
  height: 100vh;
  overflow: hidden;
}

.layout {
  display: flex;
  height: 100%;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background: #fff;
  border-right: 1px solid #e0e0e0;
  transition: width 0.3s ease;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.sidebar-collapsed {
  width: 64px;
}

.sidebar-header {
  padding: 16px;
  border-bottom: 1px solid #e0e0e0;
}

.collapse-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 8px;
  border-radius: 50%;
  transition: background-color 0.2s;
}

.collapse-btn:hover {
  background-color: #f5f5f5;
}

.nav-tabs {
  padding: 8px 0;
}

.nav-tab {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  cursor: pointer;
  transition: background-color 0.2s;
  color: #666;
}

.nav-tab:hover {
  background-color: #f5f5f5;
}

.nav-tab.active {
  background-color: #e3f2fd;
  color: #1976d2;
  border-right: 3px solid #1976d2;
}

.tab-icon {
  margin-right: 12px;
  font-size: 20px;
}

.tab-label {
  font-weight: 500;
}

/* 筛选内容区域 */
.filter-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.filter-section {
  margin-bottom: 24px;
}

.filter-title {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 12px;
}

.filter-items {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.filter-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  color: #666;
}

.filter-item:hover {
  background-color: #f5f5f5;
}

.filter-item.active {
  background-color: #e3f2fd;
  color: #1976d2;
}

.filter-item .material-icons {
  font-size: 16px;
  margin-right: 8px;
}

/* 主内容区样式 */
.main-content {
  flex: 1;
  overflow-y: auto;
  background: #fafafa;
}

.content-header {
  padding: 24px;
  background: #fff;
  border-bottom: 1px solid #e0e0e0;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.content-header h1 {
  font-size: 24px;
  font-weight: 500;
  color: #333;
}

.search-box {
  min-width: 300px;
}

.search-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.search-icon {
  position: absolute;
  left: 12px;
  color: #666;
  font-size: 20px;
}

.search-input {
  width: 100%;
  padding: 12px 40px 12px 44px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.2s;
  background: #fafafa;
}

.search-input:focus {
  outline: none;
  border-color: #1976d2;
  background: #fff;
  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.1);
}

.clear-search {
  position: absolute;
  right: 8px;
  background: none;
  border: none;
  color: #666;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  transition: background-color 0.2s;
}

.clear-search:hover {
  background: #f5f5f5;
}

/* 筛选状态样式 */
.filter-status {
  padding: 16px 24px;
  background: #fff;
  border-bottom: 1px solid #e0e0e0;
}

.filter-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}

.filter-chip {
  display: flex;
  align-items: center;
  padding: 6px 12px;
  background: #e3f2fd;
  color: #1976d2;
  border-radius: 16px;
  font-size: 14px;
  gap: 6px;
}

.filter-chip .material-icons {
  font-size: 14px;
}

.remove-chip {
  cursor: pointer;
  font-weight: bold;
  font-size: 16px;
  line-height: 1;
}

.clear-all-btn {
  background: none;
  border: 1px solid #ddd;
  padding: 6px 12px;
  border-radius: 16px;
  color: #666;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}

.clear-all-btn:hover {
  background: #f5f5f5;
}

/* 瀑布流样式 */
.masonry-grid {
  padding: 24px;
  column-count: 4;
  column-gap: 16px;
}

.masonry-item {
  break-inside: avoid;
  margin-bottom: 16px;
  cursor: pointer;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  transition: transform 0.2s, box-shadow 0.2s;
}

.masonry-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.masonry-item img {
  width: 100%;
  height: auto;
  display: block;
}

/* Overlay样式 */
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.overlay-content {
  background: #fff;
  border-radius: 12px;
  display: flex;
  max-width: 90vw;
  max-height: 90vh;
  overflow: hidden;
}

.photo-container {
  flex: 1;
  max-width: 60%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #000;
}

.photo-container img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.photo-info {
  flex: 1;
  padding: 24px;
  max-width: 400px;
  overflow-y: auto;
}

.info-section {
  margin-bottom: 24px;
}

.info-section h3 {
  margin-bottom: 12px;
  color: #333;
  font-weight: 500;
}

.info-item {
  margin-bottom: 12px;
}

.info-item label {
  display: block;
  margin-bottom: 4px;
  color: #666;
  font-size: 14px;
}

.info-item input,
.info-item textarea {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.info-item textarea {
  resize: vertical;
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag {
  background: #e3f2fd;
  color: #1976d2;
  padding: 4px 8px;
  border-radius: 16px;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.remove-tag {
  cursor: pointer;
  font-weight: bold;
}

.tag-input {
  padding: 4px 8px;
  border: 1px solid #ddd;
  border-radius: 16px;
  font-size: 12px;
  min-width: 80px;
}

.action-buttons {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s;
}

.btn-primary {
  background: #1976d2;
  color: white;
}

.btn-primary:hover {
  background: #1565c0;
}

.btn-secondary {
  background: #f5f5f5;
  color: #666;
}

.btn-secondary:hover {
  background: #e0e0e0;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .masonry-grid {
    column-count: 3;
  }
}

@media (max-width: 768px) {
  .masonry-grid {
    column-count: 2;
  }

  .overlay-content {
    flex-direction: column;
    max-width: 95vw;
  }

  .photo-container {
    max-width: 100%;
    max-height: 50vh;
  }
}

@media (max-width: 480px) {
  .masonry-grid {
    column-count: 1;
  }
}
</style>